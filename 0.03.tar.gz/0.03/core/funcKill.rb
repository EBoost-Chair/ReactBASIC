def KillFunc()
  $S_Var={}
end