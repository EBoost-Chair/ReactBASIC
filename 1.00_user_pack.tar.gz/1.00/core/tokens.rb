$NoCmd_a=0
$NoCmd_b=0
$NoCmdToken=0
