#!/usr/bin/ruby
# tokens.rb
# Modules should use these vars to communicate
# with RBasic main body.
# By Lonely_Man<2754887003@qq.com>

# NoCommandError
$NoCmd_a=0
$NoCmd_b=0
$NoCmdToken=0

# Release Token
$RTken=0

# Pre Check Token
$PCheck_a=0
$PCheck_b=0
