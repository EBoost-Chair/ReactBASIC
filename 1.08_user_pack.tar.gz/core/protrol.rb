#!/usr/bin/ruby
# protrol.rb
# Modules should use this to save the vars,special vars and subs.
# By Lonely_Man<2754887003@qq.com>
$Var={}
$Sub={}
$S_Var={}
$Sym_Table={"~c"=>",","~~"=>"~","~s"=>"#"}