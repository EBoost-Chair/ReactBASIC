#!/usr/bin/ruby
# funcKill.rb
# RBasic uses this to reset the $S_Var.
# By Lonely_Man<2754887003@qq.com>
def KillFunc()
  $S_Var={}
end